#include<iostream>
using namespace std;

class StudentInfo {
    char name[100];
    int studentID;


public:
    void init(){
        cout << "Enter your name: " ;
        cin >> this->name;
        cout << endl;

        cout << "Enter your ID: ";
        cin >> this->studentID;
        cout << endl;

        cout << "Information saved \n\n\n";
    }

    void printStudentName(){ // camelCase
        cout << "Your name is: ";
        cout << this->name << endl;
    }

    void printStudentID(){
        cout << "Your student ID: ";
        cout << this->studentID << endl;
    }

};

int main()
{
    StudentInfo s;

    s.init();
    s.printStudentName();
    s.printStudentID();
    return 0;
}
